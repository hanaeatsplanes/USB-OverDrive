G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.1*
G04 #@! TF.CreationDate,2026-07-06T16:37:51-04:00*
G04 #@! TF.ProjectId,USB OverDrive,55534220-4f76-4657-9244-726976652e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.1) date 2026-07-06 16:37:51*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
